# CNS – Cryptography and Network Security (Programs 1–20)

These are separate educational C programs based on Programs 1–20 in the supplied CNS list.

## Compile and run
Use GCC:
```bash
gcc 01_caesar_cipher.c -o program
./program
```
On Windows:
```bash
gcc 01_caesar_cipher.c -o program.exe
program.exe
```
Compile each `.c` file separately. Some programs are demonstrations of a concept rather than production cryptographic implementations; the DES key-schedule items (17–18) explain the specified schedule structure, and item 19 uses a clearly labelled XOR toy transform to demonstrate CBC chaining, not 3DES.

## Files
01 Caesar cipher  
02 Monoalphabetic substitution cipher  
03 Playfair encryption  
04 Polyalphabetic (Vigenere) cipher  
05 Affine Caesar cipher  
06 Affine cipher frequency-based candidate search  
07 Simple substitution frequency demonstration  
08 Keyword-based monoalphabetic cipher  
09 Playfair decryption (enter the keyword used for encryption)  
10 Playfair encryption with the fixed matrix from the assignment  
11 Playfair keyspace calculation  
12 Hill cipher using the 2x2 key matrix [[9,4],[5,7]]  
13 Recover a 2x2 Hill key from known plaintext/ciphertext pairs  
14 One-time-pad Vigenere variant  
15 Additive cipher frequency attack (top 10 shift candidates)  
16 Monoalphabetic substitution frequency approximation  
17 DES decryption subkey order  
18 DES subkey structure  
19 CBC chaining demonstration (toy transform; not secure)  
20 ECB/CBC error propagation explanation

## Important notes
- These programs are for learning and lab demonstration, not for protecting real data.
- Frequency-analysis programs provide approximations; they cannot guarantee recovery of arbitrary substitution plaintext.
- Program 9 needs the original Playfair keyword, which is not specified in the assignment text.
- Program 12 uses the matrix values shown in the PDF: 9, 4, 5, 7.
